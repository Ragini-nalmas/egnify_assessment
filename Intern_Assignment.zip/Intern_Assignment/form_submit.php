<?php
ini_set('display_errors',0);
    require 'connection.php';
    session_start();
   
    $id=mysqli_real_escape_string($con,$_POST['id']);
    $name=mysqli_real_escape_string($con,$_POST['name']);
    $class=mysqli_real_escape_string($con,$_POST['class']);
    $section=mysqli_real_escape_string($con,$_POST['section']);
    $marks=mysqli_real_escape_string($con,$_POST['marks']);
    
    
        $user_registration_query="insert into egnify(id,name,class,section,marks) values ('$id','$name','$class','$section','$marks')"; 
        //die($user_registration_query);
        $user_registration_result=mysqli_query($con,$user_registration_query) or die(mysqli_error($con));
        echo "Student successfully registered";
        ?>
        <meta http-equiv="refresh" content="3;url=add.php" />
        <?php
    
?>