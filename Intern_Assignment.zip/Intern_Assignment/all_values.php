<!DOCTYPE html>
<html>
<head>
  <title>Display all records from Database</title>
</head>
<body>

<h2>Student Details</h2>

<table border="2">
  <tr>
    <td>Id</td>
    <td> Name</td>
    <td>class</td>
    <td>section</td>
    <td>marks</td>
  </tr>

<?php

include "connection.php"; // Using database connection file here

$records = mysqli_query($con,"select * from egnify"); // fetch data from database

while($data = mysqli_fetch_array($records))
{
?>
  <tr>
    <td><?php echo $data['id']; ?></td>
    <td><?php echo $data['name']; ?></td>
    <td><?php echo $data['class']; ?></td>   
    <td><?php echo $data['section']; ?></td>
    <td><?php echo $data['marks']; ?></td>     
   sss
  </tr> 
<?php
}
?>
</table>

</body>
</html>