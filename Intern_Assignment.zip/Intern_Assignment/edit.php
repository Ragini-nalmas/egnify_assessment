<?php

include "connection.php"; // Using database connection file here

$id = $_GET['id']; // get id through query string

$qry = mysqli_query($con,"select * from egnify where id='$id'"); // select query

$data = mysqli_fetch_array($qry); // fetch data

if(isset($_POST['update'])) // when click on Update button
{
    $name = $_POST['name'];
    $class = $_POST['class'];
	
    $edit = mysqli_query($con,"update egnify set name='$name', class='$class' where id='$id'");
	
    if($edit)
    {
        mysqli_close($con); // Close connection
        header("location:retrive.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo mysqli_error();
    }    	
}
?>

<h3>Update Data</h3>

<form method="POST">
  <input type="text" name="name" value="<?php echo $data['name'] ?>" placeholder="Enter Full Name" Required>
  <input type="text" name="class" value="<?php echo $data['class'] ?>" placeholder="Enter class" Required>
  <input type="submit" name="update" value="Update">
</form>