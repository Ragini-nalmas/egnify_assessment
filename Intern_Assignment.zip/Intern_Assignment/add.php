<?php
    require 'connection.php';
?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1 ,shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Problem 1</title>

    </head>

    <body>
        <div>
            
           <div>
                <center> <h3>Student Registration Form</h3></center>

                        <form method="post" action="form_submit.php">
                    <div>
                        <label for="id"> ID:*</label>
                        
                            <input type="text"  id="name" name="id" placeholder="ID">
                        </div>
                    </div>
                    <div >
                        <label for="name" > FullName:*</label>
                       
                            <input type="text"   name="name" placeholder="First Name">
                        </div>
                
                    <div>
                        <label for="class" > Class:*</label>
                        
                            <input type="text" name="class" placeholder="Class ">
                        </div>
                    </div>
                    <div >
                        <label for="section"> Section:*</label>
                        <div>
                            <input type="text"  name="section" placeholder="Section">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="marks" > Marks:*</label>
                      
                            <input type="text"  name="marks" placeholder="Marks ">
                        </div>
                    </div>
                
                    
                    <div >
                        
                            <button type="submit">
                                SUBMIT
                            </button>
                            
                        </div>
                    </div>
                    
                
                </form>
                <form action="add.php"><button type="submit" >
                                ADD
                            </button> </form>
                 <form action="retrive.php"><button type="submit" >
                            Update and Delete
                            </button> </form>
                            <form action="all_values.php"><button type="submit" >
                            List of students
                            </button> </form>
                 



            
        </div>
    </body>
</html>
